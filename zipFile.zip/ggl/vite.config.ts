import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

// Minimal config used by the server when creating a Vite dev server.
export default defineConfig({
	plugins: [react()],
	resolve: {
		alias: [
			{ find: "@", replacement: path.resolve(__dirname, "client", "src") },
			{ find: "@shared", replacement: path.resolve(__dirname, "shared") },
		],
	},
});
import { defineConfig } from "vite";

// Minimal Vite config to satisfy server-side import when a full config
// isn't present in this workspace. If you have a custom config, replace this file.
export default defineConfig({});
